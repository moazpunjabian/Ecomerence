<?php include 'app.php';?>
<style type="text/css">
    .bg-dark {
    background-color: #343a40!important;
}
</style>

<div class="my-5"></div>

<!-- Contact -->
<section class="container">
    <div class="row">

        <!--Grid column-->
        <div class="col-lg-5 mb-4" >

            <!--Form with header-->
            <div style="background-color: white;" >

                <div class="card-header p-0">
                    <div class="bg-primary text-white text-center py-2">
                        <h3><i class="fa fa-envelope"></i> <span style="font-size: 20px;"> Write to us: </span></h3>
                        <p class="m-0" style="font-size: 20px;">We'll write rarely, but only the best content.</p>
                    </div>
                </div>
                <div class="card-body p-4">

                    <!--Body-->
                    <div class="form-group">
                        <label style="font-size: 18px;">Your name</label>
                        <div class="input-group">
                            <div class="input-group-addon bg-light" style="width: 50px;"><i class="fa fa-user text-primary"></i></div>
                            <input type="text" class="form-control" id="inlineFormInputGroupUsername" style="font-size: 16px;" placeholder="Username">
                        </div>
                    </div>
                    <div class="form-group">
                        <label style="font-size: 18px;">Your email</label>
                        <div class="input-group mb-2 mb-sm-0">
                            <div class="input-group-addon bg-light" style="width: 50px;"><i class="fa fa-envelope text-primary"></i></div>
                            <input type="text" class="form-control" id="inlineFormInputGroupUsername" style="font-size: 16px;" placeholder="Username">
                        </div>
                    </div>
                    <div class="form-group">
                        <label style="font-size: 18px;">Service</label>
                        <div class="input-group mb-2 mb-sm-0">
                            <div class="input-group-addon bg-light" style="width: 50px;"><i class="fa fa-tag prefix text-primary"></i></div>
                            <input type="text" class="form-control" id="inlineFormInputGroupUsername" style="font-size: 16px;" placeholder="Username">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Message</label>
                        <div class="input-group mb-2 mb-sm-0">
                            <div class="input-group-addon bg-light" style="width: 50px;"><i class="fa fa-pencil text-primary"></i></div>
                            <textarea class="form-control"></textarea>
                        </div>
                    </div>

                    <div class="text-center">
                        <button class="btn btn-primary btn-block rounded-0 py-2" style="font-size: 18px;">Submit</button>
                    </div>

                </div>

            </div>
            <!--Form with header-->

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-7">

            <!--Google map-->
            <div class="mb-4">
               
            </div>

            <!--Buttons-->
            <div class="row text-center">
                <div class="col-md-4">
                    <a class="bg-primary px-3 py-2 rounded text-white mb-2 d-inline-block"><i class="fa fa-map-marker fa-3x"></i></a>
                    <p style="font-size: 16px;">Johor Town, Lahore,<br>Pakistan</p>
                    
                </div>

                <div class="col-md-4">
                    <a class="bg-primary px-3 py-2 rounded text-white mb-2 d-inline-block"><i class="fa fa-phone fa-3x"></i></a>
                    <p style="font-size: 16px;">03334071388, <br> Mon - Fri, 8:00-22:00</p>
                </div>

                <div class="col-md-4">
                    <a class="bg-primary px-3 py-2 rounded text-white mb-2 d-inline-block"><i class="fa fa-envelope fa-3x"></i></a>
                    <p style="font-size: 16px;">info@gmail.com <br> website@gmail.com</p>
                </div>
                

                <div class="map-responsive" style="padding-left: 50px;"> 
                   <iframe  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3403.6344262369234!2d74.29148141462919!3d31.451729757676326!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39190143e0e99feb%3A0xf39379efff4dd86!2sUniversity%20of%20Management%20%26%20Technology!5e0!3m2!1sen!2s!4v1587065269140!5m2!1sen!2s" width="400" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                    </div>

            </div>

        </div>
       <!--Grid column-->
    </div>


</section>

