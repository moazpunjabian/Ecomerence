<!DOCTYPE html>
<html>
<head>
	<title>About US</title>
	<?php include 'app.php';?>
</head>
<body style="">
	<?php include 'header.php';?>
	<?php include 'navbar.php';?>
	<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-arrow-up"></i></button>
	<br>
	<div class="container">
		<div class="row">
			<div class="heading-style"> ABOUT US</div>
		</div>
		<div class="row">
			<div  class="text-back">
				<div class="col-span-12 text-padding" >
					<span class="mini-heading"><b>Our Philosophy</b> </span><br>
					<div class="text-style" >
						At Gul Ahmed, we draw our inspirations from the diverse global arena and pack it under one roof, to share the fact that beauty is universal. We constantly strive to challenge the limitations of all the possibilities when it comes to weaving, printing, embroidery & embellishments. The cloth used is not mere fabric for us, we treat it like an artist treats his canvas; with the love, respect and dedication that it deserves. Here at Gul Ahmed, we understand that style and fashion are a vital part of your lives and so we strive to bring it to your doorstep in the easiest possible way. Gul Ahmed’s motto has always been to provide excellent quality and service.
					</div>
					<br><br>
					<hr>		
				</div>	
			</div>

		</div>
		<div class="row">
			<div  class="text-back">
				<div class="col-span-12 text-padding" >
					<span class="mini-heading"><b>About Ideas by Gul Ahmed</b> </span><br>
					<div class="text-style" >
						At Ideas by Gul Ahmed, you will find a variety of fashion lines including prêt wear, unstitched fabric (for males and females), polo shirts, formal and semi formal wear (for men) and the diverse range of casual and formal wear (for women). Over the years, Gul Ahmed has introduced a number of new trends including high-class G.prêt wear, Chantilly Chiffon, Chairman Latha (for men), Digital-print Kurtis, Accessories (shoes and handbags), Home Items (bedding, cushions and bath items) and so much more. Our designs are fashionably contemporary yet timeless because of their strong pedigree. It is our originality and respect for business ethics that today, Gul Ahmed ranks as one of the leading clothing brands across Asia. Gul Ahmed not only provides fashion at great value, but also caters to various customer needs by offering a diverse product mix. This leads to a complete and enjoyable retail experience. At Gul Ahmed we don’t just aim at setting trends, but believe in mastering them. As a result of this, the chain has expanded up to over 100 outlets across Pakistan since its inception in 2003. This has contributed greatly to it becoming the largest lifestyle and fashion store in Pakistan.
					</div>	
					<br><br>
					<hr>	
				</div>	
			</div>
		</div>
		<div class="row">
			<div  class="text-back">
				<div class="col-span-12 text-padding">
					<span class="mini-heading"><b>About the Company</b> </span><br>
					<div class="text-style" >
						The story of textiles in the subcontinent is the story of Gul Ahmed. The group began trading in textiles in the early 1900s. The group entered in the field of manufacturing with the establishment of today's iconic name of Gul Ahmed Textile Mills Ltd (GTM).<br><br>
						With an installed capacity of more than 130,000 spindles, 300 state-of-the-art weaving machines and most modern yarn dyeing, processing & stitching units, Gul Ahmed is a composite unit – making everything from cotton yarn to finished products. Gul Ahmed has its own captive power plant comprising of gas engines, gas & steam turbines, and backup diesel engines. Believing in playing its role in protecting the environment, Gul Ahmed has also set up a waste water treatment plant to treat 100% of its effluent, bringing it to NEQS levels.<br><br> 
						Today, Gul Ahmed is a vertically-integrated operation, with everything from manufacturing across all stages, to retail all under one umbrella. The company was listed on Karachi Stock Exchange in 1972
					</div>		
				</div>	
			</div>
		</div>
	</div>

<br><br><br><br>
	<?php include 'footer.php';?>
	<script type="text/javascript" src="js/top_btn.js"></script>
</body>
</html>