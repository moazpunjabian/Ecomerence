<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <?php include 'app.php';?>
</head>
<body style="#">
	 <?php include 'header.php';?>
      <?php include 'navbar.php';?>
 <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-arrow-up"></i></button>
 <!-- ABC List -->
    <div class="container">
    	<div class="row">
    	
    		<div class="col-sm-12">
    			<ol >
    				<li class="li-style"><a href="#" class="link-color"> A</a></li>
    				<li class="li-style"><a href="#" class="link-color"> B</a></li>
    				<li class="li-style"><a href="#" class="link-color"> C</a></li>
    				<li class="li-style"><a href="#" class="link-color"> D</a></li>
    				<li class="li-style"><a href="#" class="link-color"> E</a></li>
    				<li class="li-style"><a href="#" class="link-color"> F</a></li>
    				<li class="li-style"><a href="#" class="link-color"> G</a></li>
    				<li class="li-style"><a href="#" class="link-color"> H</a></li>
    				<li class="li-style"><a href="#" class="link-color"> I</a></li>
    				<li class="li-style"><a href="#" class="link-color"> J</a></li>
    				<li class="li-style"><a href="#" class="link-color"> K</a></li>
    				<li class="li-style"><a href="#" class="link-color"> L</a></li>
    				<li class="li-style"><a href="#" class="link-color"> M</a></li>
    				<li class="li-style"><a href="#" class="link-color"> N</a></li>
    				<li class="li-style"><a href="#" class="link-color"> O</a></li>
    				<li class="li-style"><a href="#" class="link-color"> P</a></li>
    				<li class="li-style"><a href="#" class="link-color"> Q</a></li>
    				<li class="li-style"><a href="#" class="link-color"> R</a></li>
    				<li class="li-style"><a href="#" class="link-color"> S</a></li>
    				<li class="li-style"><a href="#" class="link-color"> T</a></li>
    				<li class="li-style"><a href="#" class="link-color"> U</a></li>
    				<li class="li-style"><a href="#" class="link-color"> V</a></li>
    				<li class="li-style"><a href="#" class="link-color"> W</a></li>
    				<li class="li-style"><a href="#" class="link-color"> X</a></li>
    				<li class="li-style"><a href="#" class="link-color"> Y</a></li>
    				<li class="li-style"><a href="#" class="link-color"> Z</a></li>

    			</ol>
    		</div>
	</div>  	
    </div>
    <!-- ABC List -->
        <div class="container"><hr></div>
  <!--   Brand-section-1 -->

    <div class="container">
    	<div class="row row-padding" >
    		<div class="col-sm-12">
    			<span class="category-size"><a href="#" class="link-color">	A </a></span>
    			
    		</div>
    		
    	</div>
    	<br>
    	<div class="row row-padding" >
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo1.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Aqua </a></span>    			
    		</div>
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo1.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Aqua </a></span>    			
    		</div>    		
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo1.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Aqua </a></span>   			
    		</div>   		
    	</div>
    		<div class="row row-padding" >
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo1.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Aqua </a></span>    			
    		</div>
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo1.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Aqua </a></span>    			
    		</div>   		
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo1.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Aqua </a></span>    			
    		</div>  		
    	</div>
    			<div class="row row-padding" >
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo1.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Aqua </a></span>  			
    		</div>
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo1.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Aqua </a></span> 			
    		</div>  		
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo1.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Aqua </a></span>			
    		</div>    		
    	</div>  	
    </div>
 <!--   Brand-section-1 -->   
    <div class="container"><hr></div>
 <!--   Brand-section-2 -->  
        <div class="container">
    	<div class="row row-padding" >
    		<div class="col-sm-12">
    			<span class="category-size"><a href="#" class="link-color">	B </a></span>
    			
    		</div>
    		
    	</div>
    	<br>
    	<div class="row row-padding" >
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo2.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Bella </a></span>    			
    		</div>
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo2.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Bella </a></span>    			
    		</div>    		
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo2.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Bella </a></span>   			
    		</div>   		
    	</div>
    		<div class="row row-padding" >
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo2.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Bella </a></span>    			
    		</div>
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo2.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Bella </a></span>    			
    		</div>   		
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo2.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Bella </a></span>    			
    		</div>  		
    	</div>
    			<div class="row row-padding" >
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo2.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Bella </a></span>  			
    		</div>
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo2.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Bella </a></span> 			
    		</div>  		
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo2.jfif" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Bella </a></span>			
    		</div>    		
    	</div>  	
    </div>
    <!--   Brand-section-2 --> 
       <div class="container"><hr></div>
    <!--   Brand-section-3 --> 
        <div class="container">
    	<div class="row row-padding" >
    		<div class="col-sm-12">
    			<span class="category-size"><a href="#" class="link-color">	C </a></span>
    			
    		</div>
    		
    	</div>
    	<br>
    	<div class="row row-padding" >
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo3.png" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Coke </a></span>    			
    		</div>
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo3.png" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Coke </a></span>    			
    		</div>    		
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo3.png" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Coke </a></span>   			
    		</div>   		
    	</div>
    		<div class="row row-padding" >
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo3.png" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Coke </a></span>    			
    		</div>
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo3.png" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Coke </a></span>    			
    		</div>   		
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo3.png" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Coke </a></span>    			
    		</div>  		
    	</div>
    			<div class="row row-padding" >
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo3.png" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Coke </a></span>  			
    		</div>
    			<div class="col-sm-4">
    			<div><img src="img/brand_logo3.png" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Coke </a></span> 			
    		</div>  		
    		<div class="col-sm-4">
    			<div><img src="img/brand_logo3.png" id="brand-logo"></div>
    			<span class="brand-link"><a href="#" class="link-color"> Coke </a></span>			
    		</div>    		
    	</div>  	
    </div>
    <!--   Brand-section-3 -->
   
    <?php include 'footer.php';?>
<script type="text/javascript" src="js/top_btn.js"></script>
</body>
</html>