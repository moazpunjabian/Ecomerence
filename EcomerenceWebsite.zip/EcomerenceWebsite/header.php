

	<div class="sticky-top">
	<div class="maindiv">
		<div class="container container-div " >
			<div class="row">		
				<div class="col-sm-9">
					<span id="logo-span"><img src="img/prep4job_logo.png" class="img-responsive img-logo" alt="img/prep4job_logo.png" ></span>
					<span id="search-bar-span">
						<input type="text"  placeholder="What you are looking for.." name="search" id="search-bar-size" style="">
						<button type="submit" class="search-button"><i class="fa fa-search"></i></button>
					</span>
				</div>
				<div class="col-sm-1"></div>
				<div class="col-sm-2">
					<div class="dropdown">
						<i class="fa fa-user icon-font dropdown" ></i>
						<div class="dropdown-content">
							<a href="#">Login</a>
							<a href="#">Register</a>
							<a href="#">Help</a>
						</div>
					</div>
					<button class="button-icon"><i class="fa fa-heart icon-font icon-font-spacing" ></i></button>
					<button class="button-icon"><i class="fa fa-shopping-cart icon-font icon-font-spacing" ></i></button>
				</div>

			</div> 
		</div>
	</div>
	</div>
