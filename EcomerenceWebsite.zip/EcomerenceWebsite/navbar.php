<div class="topnav" id="myTopnav">
 <!--  <a href="#home" class="active">MENU</a> -->
  <a href="#news"></a>
  <a href="index.php">HOME</a>
  <a href="shop.php">SHOP</a>
   <a href="#news">CHILD</a>
  <a href="#contact">SHOE</a>
  <a href="#about">RUN</a>
  <a href="#news">CHILD</a>
  <a href="#contact">FOOT BALL</a>
  <a href="contact-us.php">CONTACT US</a>
  <a href="about-us.php">ABOUT US</a>
  <a href="#about" style="color: #4CAF50;">PROMOTIONS</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
<script type="text/javascript" src="js/nav-bar.js"></script>