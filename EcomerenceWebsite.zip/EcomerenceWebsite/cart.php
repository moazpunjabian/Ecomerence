<!DOCTYPE html>
<html>
<head>
	<title></title>
  <?php include 'app.php';?>
</head>

<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
<script src='js/jquery.zoom.js'></script>
<script>

</script>
<body >
  <?php include 'header.php';?>
  <?php include 'navbar.php';?>
  <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-arrow-up"></i></button>
  <br> <br>
  <div class="container">

   <div class="row">
       <div class="col-sm-2">
           <table >
               <tr >
                   <td class="cart-img-padding">
                       <img src="img/cart1.jpg" alt="Nature" id="cart-img-size" onclick="myFunction(this);">
                   </td>
               </tr>
               <tr >
                   <td class="cart-img-padding">
                    <img src="img/cart2.jpg" alt="Snow" id="cart-img-size" onclick="myFunction(this);">
                </td>
            </tr>
            <tr >
               <td class="cart-img-padding">
                <img src="img/cart2.jpg" alt="Snow" id="cart-img-size" onclick="myFunction(this);">
            </td>
        </tr>
    </table>
</div>
<div class="col-sm-5">
  <span class='zoom' id='ex1'>
     <img src='img/cart1.jpg' id="expandedImg" class="img-responsive" width='500' height='500' alt='Daisy on the Ohoopee'/>

 </span>
</div>
<div class="col-sm-1"></div>
<div class="col-sm-4">
    <br>
    <div class="fontstyle1 fontsize1"> Shirt </div>
    <div class="fontstyle1 fontsize3">Price</div>
    <div class="fontstyle1 fontsize2"> USD 145.00 </div>
    <div class="fontstyle1 fontsize3">Size</div>
    <div>
     <label class="lbl"> <div class="check-label">XS</div>
      <input type="radio" checked="checked" name="radio">
      <span class="checkmark"></span>
  </label>
  <label class="lbl"> <div class="check-label">S</div>
      <input type="radio" name="radio">
      <span class="checkmark"></span>
  </label>
  <label class="lbl"> <div class="check-label">M</div>
      <input type="radio" name="radio">
      <span class="checkmark"></span>
  </label>
  <label class="lbl"> <div class="check-label">L</div>
      <input type="radio" name="radio">
      <span class="checkmark"></span>
  </label>
</div>
<div class="fontstyle1 fontsize2">Quantity</div>
<div>
    
   <div class="input-group">
      <span >
        <button type="button" class="quantity-left-minus btn btn-danger btn-number">
         <span class="glyphicon glyphicon-minus"></span>
     </button>
 </span>
 <input type="text" id="quantity" name="quantity" class="" value="10" min="1" max="100">
 <span>
  <button type="button" class="quantity-right-plus btn btn-success btn-number">
     <span class="glyphicon glyphicon-plus"></span>
 </button>
</span>
</div>

</div>
<br>
<div>
    <button class="button-add butn-hover">Add to Cart</button>
    <a href="checkout.php"><button class="button-add butn-hover">Check Out</button></a>
</div>

</div>

</div>
</div>
<br>   

<?php include 'footer.php';?>
<script type="text/javascript" src="js/top_btn.js">
</script>

</body>
</html>